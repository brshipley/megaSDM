#### List of Things To Do ####
#Paper--------------------------------------
#TODO: redo flowcharts
#TODO: ensure that data inputs section is correct
#TODO: make sure references are in proper citation form

#When submitting:
  #Submit tracked changes to manuscript
  #upload new figures (if necessary) and delete redundant ones
  #

#Function Management------------------------

#TODO: even if only one scenario, name it something

#Raster Management--------------------------
#TODO: Describe training vs. test area more completely

#Occurrence Data Collection-----------------
#TODO: add in paper's supplementary information to the occurrence data documentation.


#Varela Sample (OccurrenceManagement)----------


#Background Buffers---------------------------


#Background Point Generation----------------

#Varying environmental layers per species----------

#Maxent Modelling---------------------------
#TODO: test maxent.jar copy
#TODO: have megaSDM download the maxent.jar file and put it in the correct directory

#Ensemble Modelling, Forecast, HindCast----------------


#Additional Stats--------------------------------------


#Time Maps----------------------------------------


#Dispersal Rate-----------------------------------


#Richness Maps------------------------------------

